require 'pry'
# Get input from the user:  the cheer
def call_out_cheer
  gets.chomp
end

# Determine the mascot's response based on the argument
# passed to the method
def mascot_sign_for(input)
   case input
     # when ''
     #   call_out_cheer
     when "RED HOT"
       "H-O-T!"
     when "DO IT AGAIN"
       "Go, Fight, Win"
     when "2 BITS"
       "Holler!"
     when "STOMP YOUR FEET"
      "STOMP!"
     else
       "Go Team!"
   end
end
# Print the argument passed to the method
def display(response)
     puts response
end

# This method will control the flow of the application,
# making use of the other three methods.
def coordinate_cheers
  puts "say something"
  input = ""
  empty_input_counter = 0
  while ((input != "game over") && (empty_input_counter < 2))
    input = call_out_cheer
    if input == ''
      empty_input_counter += 1
      display(mascot_sign_for(input))
    else
      empty_input_counter = 0
      display(mascot_sign_for(input))
    end
  end

end
