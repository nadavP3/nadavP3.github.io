require_relative "../mascot"
