$(document).ready(function() {
  $('#login-button').click(function(event){
    event.preventDefault();
    $.ajax({
      method: "get",
      url: "/login"
    }).done(
    function(response) {
      $("body").find("#login-form").remove();
      $("nav").after(response);
    }); // Closes done response
  }); // Closes login-button click event

  $('#create-post-button').click(function(event){
    event.preventDefault();
    $.ajax({
      method: "get",
      url: "posts/new"
    }).done(
    function(response) {
      $("body").find("#create-post-form").remove();
      $("nav").after(response);
    }); // Closes done response
  }); // Closes login-button click event

  $('body').on('submit', '#post-form', function(event){
    event.preventDefault();
    $.ajax({
      method: "POST",
      url: "/posts",
      data: $(this).serialize()
    }).done(function(response) {
      $("#post-list").prepend(response);
      $("body").find("#create-post-form").remove();
    });
  });

}); // Closes DOCUMENT READY
