### v0.1.0
* Integrate rspec
* Add rake db:reset task
* Upgrade rake to 10.1.0
* Upgrade sinatra to 1.4.3
* Upgrade sinatra-contrib to 1.4.1

### v.0.1.1
* Implement a basic class and spec to exercise it
* Relocate misplaced comma set
* Convert models/README to Markdown
* Correct misusue of e.g.
* Convert helpers/README to Markdown
* Implement a "em" helper for reference; improve README
