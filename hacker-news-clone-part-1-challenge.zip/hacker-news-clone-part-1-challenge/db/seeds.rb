phil = User.create(username: "hotbanana69", password: "stickysauce")
devin = User.create(username: "FBIGuy", password: "stickysauce")

first_post = Post.create(title: "I love bananas!", body: "Bananas are the greatest fruit. And the greatest vegetable. You heard me right.", author_id: phil.id)

two_post = Post.create(title: "Did I stutter?", body: "BANANAS ARE THE BEST VEGETABLE!!!!", author_id: phil.id)

Comment.create(body: "No they're not!", author_id: devin.id, post_id: first_post.id)

Comment.create(body: "Yes they are, you fool!", author_id: phil.id, post_id: first_post.id)


