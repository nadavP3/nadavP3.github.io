class User < ActiveRecord::Base
  has_many :posts, foreign_key: "author_id"
  has_many :comments, foreign_key: "author_id"

  validates_uniqueness_of :username, presence:true
  validates :password, length: { minimum: 8 }

  has_secure_password
end
