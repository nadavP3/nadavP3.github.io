get '/' do
  redirect '/posts'
end

get '/posts' do

  @posts = Post.all
  erb :'posts/index'

end


get '/posts/new' do
  redirect_no_login
  if request.xhr?
    erb :'posts/new', layout: false
  else
    erb :'posts/new'
  end
end

post '/posts' do
  redirect_no_login
  if request.xhr?
    @post = Post.new(params[:post])
    if @post.save
      erb :'partials/_new_post', layout: false
    else
      @errors = @post.errors.full_messages
      erb :'posts/new'
    end
  else
    @post = Post.new(params[:post])
    if @post.save
      redirect '/posts'
    else
      @errors = @post.errors.full_messages
      erb :'posts/new'
    end
  end
end


get '/posts/:id' do

  #gets params from url

  @post = Post.find(params[:id]) #define instance variable for view

  erb :'posts/show' #show single post view

end


get '/posts/:id/edit' do
  redirect_no_login

  @post = Post.find(params[:id]) #define

  erb :'posts/edit' #show edit post view

end


put '/posts/:id' do
  redirect_no_login
  #get params from url
  @post = Post.find(params[:id]) #define variable to edit

  @post.assign_attributes(params[:post]) #assign new attributes

  if @post.save #saves new post or returns false if unsuccessful
    redirect '/posts' #redirect back to posts index page
  else
    erb :'posts/edit' #show edit post view again(potentially displaying errors)
  end

end


delete '/posts/:id' do
  redirect_no_login
  #get params from url
  @post = Post.find(params[:id]) #define post to delete

  @post.destroy #delete post

  redirect '/posts' #redirect back to posts index page

end
