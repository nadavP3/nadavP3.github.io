post '/posts/:post_id/comments' do

  @post = Post.find(params[:post_id])

  @comment = @post.comments.new(params[:comment])

  if @comment.save
    redirect "/posts/#{@post.id}"
  else
    redirect "/posts/#{@post.id}"
  end

end





delete '/posts/:post_id/comments/:id' do

  @post = Post.find(params[:post_id])

  @comment = @post.comments.find(params[:id])

  @comment.destroy

  redirect "/posts/#{@post.id}"

end
